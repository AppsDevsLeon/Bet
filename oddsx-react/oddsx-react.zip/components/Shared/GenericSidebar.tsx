"use client";

import React, { useState } from "react";

export type GenericNavItem = {
  id: number | string;
  label: string;
  href: string;
  iconNode?: React.ReactNode; // opcional (para otros sidebars)
  count?: number;
};

export type SidebarSection = {
  id: string;
  title?: string;
  searchable?: boolean;
  items: GenericNavItem[];
};

export type GenericSidebarProps = {
  sections: SidebarSection[];
  activeId: number | string;
  onSelectItem: (id: number | string) => void;
  showMainBlock?: boolean;
};

const BLUE = "#1E3C8E";
const BORDER_LIGHT = "#e5e7eb";
const FONT_FAMILY =
  'system-ui, -apple-system, BlinkMacSystemFont, "Inter", sans-serif';

export default function GenericSidebar({
  sections,
  activeId,
  onSelectItem,
  showMainBlock = false,
}: GenericSidebarProps) {
  const [searchTerm, setSearchTerm] = useState("");

  return (
    <div
      style={{
        width: "100%",
        backgroundColor: "#fff",
        fontFamily: FONT_FAMILY,
        fontSize: "14px",
        lineHeight: 1.3,
        color: BLUE,
        padding: "12px 16px 24px 16px",
        borderRadius: "8px 0 0 0",
      }}
    >
      {sections.map((section, sectionIdx) => {
        const visibleItems = section.searchable
          ? section.items.filter((it) =>
              it.label.toLowerCase().includes(searchTerm.toLowerCase())
            )
          : section.items;

        // vamos a manejar 2 modos:
        //  - modo "simple list" (timeframes) -> sin header arriba
        //  - modo "popular" (si lo usas luego) -> con header/title y estrellita
        //
        // Para tu screenshot de timeframes (All, 15 Min, etc.) es sólo UNA sección.
        // Vamos a pintar esa sección con estilo "list simple".

        const isFirstBlock = sectionIdx === 0;

        return (
          <div key={section.id} style={{ marginBottom: "16px" }}>
            {/* header de sección si aplica (ej. "Popular") */}
            {section.title && (
              <div
                style={{
                  color: BLUE,
                  fontSize: "16px",
                  lineHeight: 1.2,
                  fontWeight: 600,
                  marginBottom: "12px",
                }}
              >
                {section.title}
              </div>
            )}

            {/* SEARCH INPUT si quieres tener buscador en esa sección */}
            {section.searchable ? (
              <div style={{ marginBottom: "12px" }}>
                <div style={{ position: "relative" }}>
                  <input
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search"
                    style={{
                      width: "100%",
                      fontSize: "13px",
                      borderRadius: "4px",
                      border: `1px solid ${BORDER_LIGHT}`,
                      padding: "6px 8px 6px 28px",
                      lineHeight: 1.2,
                      color: BLUE,
                      outline: "none",
                    }}
                  />
                  <span
                    style={{
                      position: "absolute",
                      left: "8px",
                      top: "50%",
                      transform: "translateY(-50%)",
                      fontSize: "12px",
                      lineHeight: 1,
                      color: BLUE,
                    }}
                  >
                    🔍
                  </span>
                </div>
              </div>
            ) : null}

            {/* LISTA DE ITEMS */}
            <ul
              style={{
                listStyle: "none",
                margin: 0,
                padding: 0,
              }}
            >
              {visibleItems.map((it) => {
                const isActive = String(activeId) === String(it.id);

                const bgColor = isActive ? BLUE : "transparent";
                const textColor = isActive ? "#fff" : BLUE;

                return (
                  <li
                    key={it.id}
                    onClick={() => onSelectItem(it.id)}
                    style={{
                      cursor: "pointer",
                      userSelect: "none",

                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",

                      borderRadius: "6px",

                      // spacing vertical tipo tu captura
                      padding: "10px 8px",

                      backgroundColor: bgColor,
                    }}
                  >
                    {/* IZQUIERDA: icono opcional + label */}
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "8px",
                        minWidth: 0,
                        flex: "1 1 auto",
                        color: textColor,
                        fontWeight: 500,
                        fontSize: "14px",
                        lineHeight: 1.2,
                      }}
                    >
                      {/* iconNode si algún item lo trae (no en tu screenshot de timeframes) */}
                      {it.iconNode ? (
                        <span
                          style={{
                            width: "16px",
                            height: "16px",
                            flexShrink: 0,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            color: textColor,
                          }}
                        >
                          {it.iconNode}
                        </span>
                      ) : null}

                      {/* label */}
                      <span
                        style={{
                          whiteSpace: "nowrap",
                          textOverflow: "ellipsis",
                          overflow: "hidden",
                          maxWidth: "140px",
                          color: textColor,
                        }}
                      >
                        {it.label}
                      </span>
                    </div>

                    {/* DERECHA: count y/o estrellita si activo */}
                    <div
                      style={{
                        flexShrink: 0,
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                        fontSize: "13px",
                        lineHeight: 1,
                        color: textColor,
                        fontWeight: 500,
                        minWidth: "24px",
                        justifyContent: "flex-end",
                      }}
                    >
                      {typeof it.count === "number" ? (
                        <span style={{ color: textColor }}>{it.count}</span>
                      ) : null}

                      {/* si quisieras estrellita, sólo cuando active */}
                      {isActive ? (
                        <svg
                          width={16}
                          height={16}
                          viewBox="0 0 24 24"
                          fill={textColor} // importante: blanco con fondo azul
                          aria-hidden="true"
                          style={{ display: "block" }}
                        >
                          <path d="M12 2.5 14.9 9l7.1.6-5.4 4.6 1.7 7-6.3-3.9-6.3 3.9 1.7-7L2 9.6 9.1 9 12 2.5Z" />
                        </svg>
                      ) : null}
                    </div>
                  </li>
                );
              })}
            </ul>

            {/* DIVIDER SOLO si esta sección es la primera y hay más después */}
            {isFirstBlock && sections.length > 1 ? (
              <div
                style={{
                  width: "100%",
                  height: "1px",
                  backgroundColor: BORDER_LIGHT,
                  margin: "16px 0 0 0",
                }}
              />
            ) : null}
          </div>
        );
      })}

      {showMainBlock ? (
        <div style={{ padding: "12px" }}>{/* banner/promo */}</div>
      ) : null}
    </div>
  );
}
