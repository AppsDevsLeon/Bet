"use client";

import React, { useState, useCallback, useRef, useEffect } from "react";
import Image from "next/image";

type Equipo = { nombre: string; logo?: string };
type Partido = {
  id: string;
  liga: string;
  torneo?: string;
  inicioISO: string;
  tv?: string;
  equipos: { visitante: Equipo; local: Equipo };
  mercados?: {
    moneyline?: { visitante?: string; local?: string };
    spread?: string;
    total?: string;
  };
};

type Seleccion = {
  partidoId: string;
  mercado: "Moneyline" | "Hándicap" | "Total";
  opcion: string;
  cuota: string;
  etiqueta: string;
};

// ---- util horario local
function formatHoraLocal(iso: string, tz = "America/Mexico_City") {
  try {
    const d = new Date(iso);
    return new Intl.DateTimeFormat("es-MX", {
      timeZone: tz,
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(d);
  } catch {
    return iso;
  }
}

// ---- datos demo
const EVENTOS: Partido[] = [
  {
    id: "2025-09-29-nyj-mia",
    liga: "NFL",
    torneo: "Regular Season (MNF)",
    inicioISO: "2025-09-29T17:15:00-06:00",
    tv: "ESPN",
    equipos: { visitante: { nombre: "New York Jets" }, local: { nombre: "Miami Dolphins" } },
    mercados: { moneyline: { visitante: "+220", local: "-160" }, spread: "Dolphins -3.5", total: "O/U 42.5" },
  },
  {
    id: "2025-09-29-cin-den",
    liga: "NFL",
    torneo: "Regular Season (MNF)",
    inicioISO: "2025-09-29T19:15:00-06:00",
    tv: "ABC",
    equipos: { visitante: { nombre: "Cincinnati Bengals" }, local: { nombre: "Denver Broncos" } },
    mercados: { moneyline: { visitante: "-120", local: "+102" }, spread: "Bengals -1.5", total: "O/U 44.5" },
  },
  {
    id: "2025-10-02-sf-lar",
    liga: "NFL",
    torneo: "Semana 5 (TNF)",
    inicioISO: "2025-10-02T19:15:00-06:00",
    tv: "Prime Video",
    equipos: { visitante: { nombre: "San Francisco 49ers" }, local: { nombre: "Los Angeles Rams" } },
    mercados: { moneyline: { visitante: "+150", local: "-180" }, spread: "Rams -3.0", total: "O/U 47.5" },
  },
  {
    id: "2025-10-05-min-cle",
    liga: "NFL",
    torneo: "Semana 5 (Tottenham)",
    inicioISO: "2025-10-05T08:30:00-06:00",
    tv: "NFL Network",
    equipos: { visitante: { nombre: "Minnesota Vikings" }, local: { nombre: "Cleveland Browns" } },
    mercados: { moneyline: { visitante: "-218", local: "+180" }, spread: "Vikings -4.5", total: "O/U 37.5" },
  },
  {
    id: "2025-10-05-den-phi",
    liga: "NFL",
    torneo: "Semana 5",
    inicioISO: "2025-10-05T12:00:00-06:00",
    tv: "CBS",
    equipos: { visitante: { nombre: "Denver Broncos" }, local: { nombre: "Philadelphia Eagles" } },
    mercados: { moneyline: { visitante: "+195", local: "-238" }, spread: "Eagles -5.5", total: "O/U 43.5" },
  },
];

// helper dims
const toDim = (v?: number | string, fallback = "0px") =>
  typeof v === "number" ? `${v}px` : (v ?? fallback);

// ====== COMPONENTE PRINCIPAL ======
export default function ApuestasNFL({
  eventos = EVENTOS,
  titulo = "Partidos y mercados (NFL)",
  className = "",
  headerH = "80px",
  sidebarW = "260px",
  gutterX = "16px",
  gutterY = "12px",
  mtExtra = "24px", // extra arriba
}: {
  eventos?: Partido[];
  titulo?: string;
  className?: string;
  headerH?: number | string;
  sidebarW?: number | string;
  gutterX?: number | string;
  gutterY?: number | string;
  mtExtra?: number | string;
}) {
  const [expandido, setExpandido] = useState<string | null>(null);
  const [selecciones, setSelecciones] = useState<Seleccion[]>([]);
  const filaRef = useRef<HTMLDivElement | null>(null);

  const toggle = useCallback((id: string) => {
    setExpandido((cur) => (cur === id ? null : id));
  }, []);

  const toggleSeleccion = useCallback((s: Seleccion) => {
    setSelecciones((cur) => {
      const exists = cur.find(
        (x) =>
          x.partidoId === s.partidoId &&
          x.mercado === s.mercado &&
          x.opcion === s.opcion &&
          x.cuota === s.cuota
      );
      return exists
        ? cur.filter(
            (x) =>
              !(
                x.partidoId === s.partidoId &&
                x.mercado === s.mercado &&
                x.opcion === s.opcion &&
                x.cuota === s.cuota
              )
          )
        : [...cur, s];
    });
  }, []);

  useEffect(() => {
    if (!expandido) return;
    const el = document.getElementById(`row-${expandido}`);
    el?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [expandido]);

  return (
    <section
      className={`ap-layout ${className}`}
      style={{
        ["--header-h" as any]: toDim(headerH),
        ["--sidebar-w" as any]: toDim(sidebarW),
        ["--gutter-x" as any]: toDim(gutterX),
        ["--gutter-y" as any]: toDim(gutterY),
        ["--mt-extra" as any]: toDim(mtExtra),
      }}
    >
      <div className="container-fluid">
        <header className="ap-head">
          <div className="title">
            <Image src="/images/icon/clock-icon.png" width={20} height={20} alt="Próximos" />
            <h3>{titulo}</h3>
          </div>
          <small className="muted">Haz clic en un partido para ver los mercados. Los precios son ilustrativos.</small>
        </header>

        <div className="ap-grid">
          {/* Lista */}
          <div className="ap-list">
            <div className="table">
              <div className="thead">
                <div>Liga</div>
                <div>Encuentro</div>
                <div>Fecha/Hora</div>
                <div>TV</div>
                <div>Cuotas</div>
              </div>

              {eventos.map((p) => {
                const activo = expandido === p.id;
                return (
                  <div key={p.id} id={`row-${p.id}`} className={`row ${activo ? "active" : ""}`} ref={filaRef}>
                    <div className="cell liga">
                      <div className="liga__wrap">
                        <span>{p.liga}</span>
                      </div>
                      {p.torneo && <div className="torneo">{p.torneo}</div>}
                    </div>

                    <button className="cell encuentro btn-link" onClick={() => toggle(p.id)} aria-expanded={activo}>
                      <div className="teams">
                        <span className="t">{p.equipos.visitante.nombre}</span>
                        <span className="vs">@</span>
                        <span className="t">{p.equipos.local.nombre}</span>
                      </div>
                      <span className={`chev ${activo ? "up" : "down"}`} />
                    </button>

                    <div className="cell fecha">{formatHoraLocal(p.inicioISO)}</div>
                    <div className="cell tv">{p.tv ?? "—"}</div>
                    <div className="cell cuotas">
                      {p.mercados?.moneyline
                        ? `${p.mercados.moneyline.visitante ?? ""} / ${p.mercados.moneyline.local ?? ""}`
                        : "—"}
                    </div>

                    {/* Panel expandible */}
                    {activo && (
                      <div className="expand">
                        {/* Moneyline */}
                        <div className="mk">
                          <div className="mk-title">Moneyline (Incl. OT)</div>
                          <div className="mk-grid">
                            <OddsButton
                              rojoVerde
                              label={p.equipos.visitante.nombre}
                              cuota={p.mercados?.moneyline?.visitante ?? ""}
                              active={selecciones.some(
                                (s) =>
                                  s.partidoId === p.id &&
                                  s.mercado === "Moneyline" &&
                                  s.opcion === p.equipos.visitante.nombre
                              )}
                              onClick={() =>
                                toggleSeleccion({
                                  partidoId: p.id,
                                  mercado: "Moneyline",
                                  opcion: p.equipos.visitante.nombre,
                                  cuota: p.mercados?.moneyline?.visitante ?? "",
                                  etiqueta: `${p.equipos.visitante.nombre} ML`,
                                })
                              }
                            />
                            <OddsButton
                              rojoVerde
                              label={p.equipos.local.nombre}
                              cuota={p.mercados?.moneyline?.local ?? ""}
                              active={selecciones.some(
                                (s) =>
                                  s.partidoId === p.id &&
                                  s.mercado === "Moneyline" &&
                                  s.opcion === p.equipos.local.nombre
                              )}
                              onClick={() =>
                                toggleSeleccion({
                                  partidoId: p.id,
                                  mercado: "Moneyline",
                                  opcion: p.equipos.local.nombre,
                                  cuota: p.mercados?.moneyline?.local ?? "",
                                  etiqueta: `${p.equipos.local.nombre} ML`,
                                })
                              }
                            />
                          </div>
                        </div>

                        {/* Hándicap */}
                        <div className="mk">
                          <div className="mk-title">Hándicap (Incl. OT)</div>
                          <div className="mk-grid">
                            <OddsButton
                              rojoVerde
                              label={p.mercados?.spread?.includes("-") ? p.mercados.spread : `${p.equipos.visitante.nombre} +3.5`}
                              cuota={"1.90"}
                              active={selecciones.some(
                                (s) => s.partidoId === p.id && s.mercado === "Hándicap" && s.opcion === "H1"
                              )}
                              onClick={() =>
                                toggleSeleccion({
                                  partidoId: p.id,
                                  mercado: "Hándicap",
                                  opcion: "H1",
                                  cuota: "1.90",
                                  etiqueta: p.mercados?.spread ?? "Hándicap 1",
                                })
                              }
                            />
                            <OddsButton
                              rojoVerde
                              label={p.mercados?.spread?.includes("-") ? "Rival +3.5" : `${p.equipos.local.nombre} -3.5`}
                              cuota={"1.90"}
                              active={selecciones.some(
                                (s) => s.partidoId === p.id && s.mercado === "Hándicap" && s.opcion === "H2"
                              )}
                              onClick={() =>
                                toggleSeleccion({
                                  partidoId: p.id,
                                  mercado: "Hándicap",
                                  opcion: "H2",
                                  cuota: "1.90",
                                  etiqueta: p.mercados?.spread ?? "Hándicap 2",
                                })
                              }
                            />
                          </div>
                        </div>

                        {/* Total */}
                        <div className="mk">
                          <div className="mk-title">Total (Incl. OT)</div>
                          <div className="mk-grid">
                            <OddsButton
                              rojoVerde
                              label={(p.mercados?.total ?? "O/U 44.5").replace("O/U", "Over")}
                              cuota={"1.84"}
                              active={selecciones.some(
                                (s) => s.partidoId === p.id && s.mercado === "Total" && s.opcion === "Over"
                              )}
                              onClick={() =>
                                toggleSeleccion({
                                  partidoId: p.id,
                                  mercado: "Total",
                                  opcion: "Over",
                                  cuota: "1.84",
                                  etiqueta: p.mercados?.total ?? "Total",
                                })
                              }
                            />
                            <OddsButton
                              rojoVerde
                              label={(p.mercados?.total ?? "O/U 44.5").replace("O/U", "Under")}
                              cuota={"1.84"}
                              active={selecciones.some(
                                (s) => s.partidoId === p.id && s.mercado === "Total" && s.opcion === "Under"
                              )}
                              onClick={() =>
                                toggleSeleccion({
                                  partidoId: p.id,
                                  mercado: "Total",
                                  opcion: "Under",
                                  cuota: "1.84",
                                  etiqueta: p.mercados?.total ?? "Total",
                                })
                              }
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* BetSlip */}
          <BetSlip
            selecciones={selecciones}
            onRemove={(i) => setSelecciones((cur) => cur.filter((_, idx) => idx !== i))}
            onClear={() => setSelecciones([])}
          />
        </div>
      </div>

      {/* estilos base */}
      <style jsx>{`
        .ap-layout {
          --sidebar-w: var(--sidebar-w, 260px);
          --header-h: var(--header-h, 80px);
          --gutter-x: var(--gutter-x, 16px);
          --gutter-y: var(--gutter-y, 12px);
          --mt-extra: var(--mt-extra, 0px);

          padding-top: calc(var(--header-h) + var(--gutter-y) + var(--mt-extra));
          padding-left: calc(var(--sidebar-w) + var(--gutter-x));
          padding-right: var(--gutter-x);
          padding-bottom: var(--gutter-y);
        }

        .ap-head .title { display: flex; align-items: center; gap: 8px; }
        .ap-head h3 { margin: 0; font-size: 1.15rem; }
        .ap-head .muted { color: var(--gray, #8b939a); }

        .ap-grid {
          display: grid;
          grid-template-columns: 1fr minmax(280px, 360px);
          gap: 16px;
          align-items: start;
        }

        .ap-list .table {
          width: 100%;
          overflow: hidden;
          border-radius: 12px;
          border: 1px solid var(--gray_light, #2b3a34);
          background: transparent;
        }

        .thead, .row {
          display: grid;
          grid-template-columns: 140px 1fr 240px 120px 180px;
          gap: 8px;
          align-items: center;
        }
        .thead {
          padding: 12px;
          font-weight: 700;
          border-bottom: 1px solid var(--gray_light, #2b3a34);
        }
        .row {
          padding: 12px;
          border-bottom: 1px solid var(--gray_light, #2b3a34);
        }
        .row.active { background: rgba(255,255,255,0.03); }

        .cell { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .liga__wrap { display: flex; align-items: center; gap: 6px; font-weight: 600; }
        .torneo { font-size: 0.85rem; color: var(--gray, #8b939a); }

        .encuentro.btn-link {
          display: flex; align-items: center; justify-content: space-between;
          gap: 8px; width: 100%; background: transparent; border: 0; color: inherit; cursor: pointer;
          text-align: left; padding: 0;
        }
        .teams { display: inline-flex; gap: 6px; align-items: center; }
        .teams .vs { color: var(--gray, #8b939a); }
        .chev { width: 10px; height: 10px; border-right: 2px solid currentColor; border-bottom: 2px solid currentColor; transform: rotate(-45deg); opacity: .7; }
        .chev.up { transform: rotate(135deg); }
        .fecha { font-weight: 600; }

        .expand {
          grid-column: 1 / -1;
          padding-top: 10px;
          display: grid;
          gap: 12px;
        }
        .mk { border-top: 1px dashed var(--gray_light, #2b3a34); padding-top: 12px; }
        .mk-title { font-weight: 700; margin-bottom: 8px; }
        .mk-grid { display: grid; grid-template-columns: repeat(2, minmax(160px, 1fr)); gap: 8px; }

        .betslip { position: sticky; top: var(--header-h, 80px); }

        @media (max-width: 1200px) {
          .thead, .row { grid-template-columns: 120px 1fr 200px 100px 140px; }
        }
        @media (max-width: 900px) {
          .ap-layout {
            padding-left: 12px;
            padding-right: 12px;
            padding-top: calc(var(--header-h, 80px) + 8px + var(--mt-extra));
            padding-bottom: 12px;
          }
          .ap-grid { grid-template-columns: 1fr; }
          .betslip { position: static; }
        }
      `}</style>

      {/* OVERRIDES ANTI-BLANCO */}
      <style jsx>{`
        .ap-layout { color-scheme: dark; background: transparent; }

        .ap-list .table,
        .ap-list .thead,
        .ap-list .row,
        .ap-list .row > .cell,
        .ap-list .expand,
        .ap-list .mk,
        .ap-list .mk-grid,
        .ap-list .mk-title {
          background: transparent !important;
          box-shadow: none !important;
        }

        .ap-list .table,
        .ap-list .thead,
        .ap-list .row,
        .ap-list .mk {
          border-color: var(--gray_light, #2b3a34) !important;
        }

        .ap-list .encuentro.btn-link {
          background: transparent !important;
          border: 0 !important;
          padding: 0 !important;
          color: var(--text, #e6e9ee) !important;
          text-decoration: none !important;
          box-shadow: none !important;
        }

        .ap-list .encuentro a,
        .ap-list .encuentro .t {
          color: var(--text, #e6e9ee) !important;
          text-decoration: none !important;
          background: transparent !important;
        }

        .ap-list .cell {
          background: transparent !important;
          color: var(--text, #e6e9ee);
        }

        .ap-list .teams .vs,
        .torneo,
        .ap-head .muted {
          color: var(--gray, #8b939a) !important;
        }

        .ap-list .expand > .mk { background: transparent !important; }

        .odds { background: var(--odd-bg, #00000026) !important; border-color: var(--odd-border, #ffffff17) !important; }
        .odds.rv:not(.active) { background: var(--odd-red-bg, #2a1313) !important; border-color: var(--odd-red, #5b2a2a) !important; }
        .odds.rv:not(.active):hover { background: var(--odd-red-bg-hover, #3a1a1a) !important; }
        .odds.rv.active { background: var(--odd-green-bg, #10331e) !important; border-color: var(--odd-green, #2a7b4b) !important; }

        .betslip,
        .bs-head,
        .bs-body,
        .bs-foot,
        .betslip .item {
          background: transparent !important;
          box-shadow: none !important;
        }
        .betslip { border-color: var(--gray_light, #2b3a34) !important; }
      `}</style>

      {/* variables globales HEX */}
      <style jsx global>{`
        :root {
          --bg: #0b0f14;
          --surface: #121820;
          --surface-2: #0f141a;

          --text: #e6e9ee;
          --muted: #8b939a;
          --muted-2: #a0a8b1;

          --border: #26313a;
          --gray_light: #2b3a34;
          --gray: #8b939a;

          --cta-bg: #613cea;
          --cta-bg-hover: #4f2fbd;
          --cta-text: #ffffff;

          --odd-bg: #00000026;
          --odd-border: #ffffff17;
          --odd-red: #5b2a2a;
          --odd-red-bg: #2a1313;
          --odd-red-bg-hover: #3a1a1a;
          --odd-green: #2a7b4b;
          --odd-green-bg: #10331e;
        }
      `}</style>
    </section>
  );
}

/* ----- Subcomponentes ----- */

function OddsButton({
  label,
  cuota,
  active,
  rojoVerde = true,
  onClick,
}: {
  label: string;
  cuota: string;
  active?: boolean;
  rojoVerde?: boolean;
  onClick?: () => void;
}) {
  return (
    <>
      <button
        className={`odds ${active ? "active" : ""} ${rojoVerde ? "rv" : ""}`}
        onClick={onClick}
        type="button"
      >
        <span className="l">{label}</span>
        <span className="p">{cuota || "—"}</span>
      </button>

      <style jsx>{`
        .odds {
          display: flex; align-items: center; justify-content: space-between;
          gap: 8px; padding: 10px 12px; border-radius: 10px;
          border: 1px solid var(--odd-border);
          background: var(--odd-bg); cursor: pointer; user-select: none;
          transition: transform .05s ease, box-shadow .15s ease, background .15s ease;
          font-weight: 600;
        }
        .odds:hover { transform: translateY(-1px); }
        .odds .l { overflow: hidden; text-overflow: ellipsis; }
        .odds .p { font-variant-numeric: tabular-nums; }

        .odds.rv { box-shadow: inset 0 0 0 1px rgba(255,255,255,0.04); }
        .odds.rv:not(.active) { background: var(--odd-red-bg); border-color: var(--odd-red); }
        .odds.rv:not(.active):hover { background: var(--odd-red-bg-hover); }
        .odds.rv.active { background: var(--odd-green-bg); border-color: var(--odd-green); }
        .odds.rv.active .p { font-weight: 800; }
      `}</style>
    </>
  );
}

function BetSlip({
  selecciones,
  onRemove,
  onClear,
}: {
  selecciones: Seleccion[];
  onRemove: (index: number) => void;
  onClear: () => void;
}) {
  const totalSelecciones = selecciones.length;
  return (
    <aside className="betslip">
      <div className="bs-head">
        <h4>Ticket ({totalSelecciones})</h4>
        <button className="clear" onClick={onClear} disabled={!totalSelecciones}>Limpiar</button>
      </div>

      <div className="bs-body">
        {selecciones.length === 0 ? (
          <div className="empty">No has seleccionado apuestas.</div>
        ) : (
          selecciones.map((s, i) => (
            <div className="item" key={`${s.partidoId}-${i}`}>
              <div className="top">
                <span className="tag">{s.mercado}</span>
                <button className="x" onClick={() => onRemove(i)} aria-label="Quitar" />
              </div>
              <div className="txt">{s.etiqueta}</div>
              <div className="odd">{s.cuota}</div>
            </div>
          ))
        )}
      </div>

      <div className="bs-foot">
        <button className="cta" disabled={!totalSelecciones}>Continuar</button>
      </div>

      <style jsx>{`
        .betslip {
          position: sticky; top: var(--header-h, 80px);
          border: 1px solid var(--gray_light, #2b3a34);
          border-radius: 12px; overflow: hidden; background: transparent;
        }
        .bs-head {
          display: flex; align-items: center; justify-content: space-between;
          padding: 10px 12px; border-bottom: 1px solid var(--gray_light, #2b3a34);
        }
        .bs-head h4 { margin: 0; font-size: 1rem; }
        .clear {
          background: transparent; color: var(--gray, #8b939a); border: 0; cursor: pointer;
        }
        .bs-body { display: grid; gap: 8px; padding: 10px; max-height: 55vh; overflow: auto; }
        .empty { color: var(--gray, #8b939a); }

        .item { border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 10px; background: rgba(0,0,0,0.15); }
        .item .top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
        .tag { font-size: .85rem; opacity: .9; }
        .x { width: 12px; height: 12px; border: 0; background: transparent; cursor: pointer; position: relative; }
        .x::before, .x::after { content: ""; position: absolute; left: 5px; top: 0; width: 2px; height: 12px; background: currentColor; }
        .x::before { transform: rotate(45deg); } .x::after { transform: rotate(-45deg); }
        .txt { font-weight: 600; margin-bottom: 2px; }
        .odd { font-variant-numeric: tabular-nums; opacity: .9; }

        .bs-foot { padding: 10px; border-top: 1px solid var(--gray_light, #2b3a34); }
        .cta {
          width: 100%; padding: 10px 12px; border: 0; border-radius: 10px;
          background: var(--cta-bg, #613cea); color: var(--cta-text, #ffffff); font-weight: 800; cursor: pointer;
        }

        @media (max-width: 900px) { .betslip { position: static; } }
      `}</style>
    </aside>
  );
}
