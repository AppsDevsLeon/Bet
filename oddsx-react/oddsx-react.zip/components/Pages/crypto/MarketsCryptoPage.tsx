"use client";

import React, { useState, useMemo, useEffect } from "react";

import GenericSidebarMobile from "@/components/Shared/GenericSidebarMobile";
import GenericSidebarDesktop from "@/components/Shared/GenericSidebar";

import MarketCardPoly from "@/components/markets/MarketCard";

import { MARKETS } from "@/public/data/marketsData";
import { getFilterForNavId } from "@/lib/cryptoCategoryMap";
import { buildSidebarSectionsDynamic } from "@/lib/buildSidebarSectionsDynamic";

import type {
  MarketCard as MarketCardType,
  OutcomeOption,
} from "@/public/data/marketsData";

/* ============================
   Hook para detectar mobile
============================ */
function useIsMobile(bp: number = 768) {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia(`(max-width:${bp}px)`);
    const apply = () => setIsMobile(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [bp]);

  return isMobile;
}

export default function MarketsCryptoPage() {
  // categoría activa en la sidebar (All, BTC, Daily...)
  const [activeNavId, setActiveNavId] = useState<number>(1);

  // estado del slip de apuesta
  const [showSlip, setShowSlip] = useState<boolean>(false);
  const [betMarket, setBetMarket] = useState<MarketCardType | null>(null);
  const [betOutcome, setBetOutcome] = useState<OutcomeOption | null>(null);
  const [betAmount, setBetAmount] = useState<string>("");

  // i18n temporal
  const t = (key: string, fallback?: string) => fallback ?? key;

  // construimos las secciones que alimentan la sidebar
  const cryptoSections = buildSidebarSectionsDynamic(t);

  // filtramos mercados según la categoría activa
  const filteredMarkets = useMemo(() => {
    const rule = getFilterForNavId(activeNavId);

    if (rule.type === "all") return MARKETS;
    if (rule.type === "asset") {
      return MARKETS.filter((m) => m.assetTag === rule.value);
    }
    if (rule.type === "range") {
      return MARKETS.filter((m) => m.rangeTag === rule.value);
    }
    return MARKETS;
  }, [activeNavId]);

  // cuando el user clickea una opción de una card
  function handleSelectOutcome(market: MarketCardType, outcome: OutcomeOption) {
    setBetMarket(market);
    setBetOutcome(outcome);
    setBetAmount("");
    setShowSlip(true);
  }

  // handler para el botón "Place Bet"
  function handlePlaceBet() {
    console.log("PLACE BET", {
      market: betMarket,
      outcome: betOutcome,
      amount: betAmount,
      token: "USDT",
    });
    alert("(demo) abrir Metamask con la apuesta");
  }

  // saber si es mobile
  const isMobile = useIsMobile();

  return (
    <main
      style={{
        // mobile: columna; desktop: fila
        display: "flex",
        flexDirection: isMobile ? "column" : "row",

        minHeight: "100vh",
        backgroundColor: "#f8fafc", // slate-50
        color: "#0f172a", // slate-900
        fontFamily: "Inter, system-ui, sans-serif",

        // en desktop probablemente ya hay header fixed afuera.
        // si tú tienes header fijo global arriba, ajusta este marginTop.
        marginTop: "0px",
      }}
    >
      {/* ================================
          SIDEBAR / NAV DE FILTROS
         ================================ */}

      {isMobile ? (
        // MOBILE:
        // barra horizontal debajo del header global,
        // aquí la ponemos arriba del contenido de las cards
        <div
          style={{
            position: "sticky",
            top: 0,
            zIndex: 1100,
            backgroundColor: "#fff",
            borderBottom: "1px solid #e2e8f0",
          }}
        >
          <GenericSidebarMobile
            sections={cryptoSections.map((section) => ({
              ...section,
              items: section.items.map((it) => ({
                ...it,
                href: "#", // no navegamos, usamos filtro local
              })),
            }))}
            activeId={activeNavId}
            onSelectItem={(id) => {
              setActiveNavId(Number(id));
            }}
          />
        </div>
      ) : (
        // DESKTOP:
        // columna izquierda fija tipo sidebar vertical
        <aside
          style={{
            display: "flex",
            flexDirection: "column",

            width: "260px",
            minWidth: "260px",
            flexShrink: 0,

            backgroundColor: "#ffffff",
            borderRight: "1px solid #e2e8f0",

            position: "sticky",
            top: "0px",
            height: "100vh",
            overflowY: "auto",
          }}
        >
          <GenericSidebarDesktop
            sections={cryptoSections.map((section) => ({
              ...section,
              items: section.items.map((it) => ({
                ...it,
                href: "#", // evitamos navegación real
              })),
            }))}
            activeId={activeNavId}
            onSelectItem={(id) => {
              setActiveNavId(Number(id));
            }}
            showMainBlock={false}
          />
        </aside>
      )}

      {/* ================================
          CONTENIDO PRINCIPAL (CARDS)
         ================================ */}
      <section
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          minWidth: 0,
          position: "relative",
        }}
      >
        {/* BODY SCROLLEABLE DE LAS CARDS */}
        <div
          style={{
            flex: "1 1 auto",
            overflowY: "auto",
            padding: isMobile ? "12px" : "16px",
            display: "flex",
            flexDirection: "column",
            rowGap: "24px",
            minWidth: 0,
          }}
        >
          {/* GRID DE MERCADOS */}
          <div
            style={{
              display: "grid",
              width: "100%",
              gap: "16px",
              minWidth: 0,
              gridTemplateColumns: isMobile
                ? "1fr" // en móvil 1 columna
                : "repeat(auto-fit, minmax(280px, 1fr))",
            }}
          >
            {filteredMarkets.map((mkt) => (
              <MarketCardPoly
                key={mkt.id}
                market={mkt}
                onSelectOutcome={handleSelectOutcome}
              />
            ))}
          </div>
        </div>

        {/* =============== SLIP DE APUESTA FLOTANTE =============== */}
        {showSlip && betMarket && betOutcome && (
          <div
            style={{
              position: "fixed",
              right: isMobile ? "12px" : "16px",
              bottom: isMobile ? "12px" : "16px",
              width: "300px",
              maxWidth: "90vw",

              borderRadius: "12px",
              border: "1px solid #cbd5e1",
              backgroundColor: "#ffffff",
              boxShadow:
                "0 24px 40px rgba(0,0,0,0.18), 0 4px 8px rgba(0,0,0,0.06)",
              padding: "16px",
              fontFamily: "Inter, system-ui, sans-serif",
              zIndex: 9999,
            }}
          >
            {/* header slip */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
                marginBottom: "12px",
              }}
            >
              <div
                style={{
                  fontSize: "13px",
                  lineHeight: "1.3",
                  color: "#0f172a",
                  fontWeight: 600,
                }}
              >
                {betMarket.title}
              </div>

              <button
                onClick={() => setShowSlip(false)}
                style={{
                  background: "transparent",
                  border: 0,
                  fontSize: "14px",
                  lineHeight: 1,
                  color: "#64748b",
                  cursor: "pointer",
                }}
                title="Close"
              >
                ✕
              </button>
            </div>

            {/* outcome seleccionado */}
            <div
              style={{
                fontSize: "12px",
                lineHeight: "1.3",
                color: "#475569",
                marginBottom: "8px",
              }}
            >
              Opción:{" "}
              <strong style={{ color: "#0f172a" }}>
                {betOutcome.label}
              </strong>{" "}
              {betOutcome.price && (
                <span
                  style={{
                    color: "#0f172a",
                    fontWeight: 600,
                    marginLeft: "4px",
                  }}
                >
                  ({betOutcome.price})
                </span>
              )}
            </div>

            {/* input monto */}
            <label
              style={{
                display: "block",
                fontSize: "12px",
                fontWeight: 500,
                color: "#0f172a",
                marginBottom: "4px",
              }}
            >
              Bet amount
            </label>
            <input
              value={betAmount}
              onChange={(e) => setBetAmount(e.target.value)}
              placeholder="0.00"
              style={{
                width: "100%",
                borderRadius: "8px",
                border: "1px solid #cbd5e1",
                fontSize: "14px",
                lineHeight: 1.3,
                color: "#0f172a",
                padding: "8px 10px",
                outline: "none",
                marginBottom: "12px",
              }}
            />

            {/* selector token */}
            <div
              style={{
                display: "flex",
                gap: "8px",
                flexWrap: "wrap",
                marginBottom: "12px",
                fontSize: "12px",
                lineHeight: 1.2,
                color: "#0f172a",
              }}
            >
              {["USDT", "USDC", "ETH"].map((tk) => (
                <button
                  key={tk}
                  style={{
                    borderRadius: "6px",
                    backgroundColor: "#f1f5f9",
                    border: "1px solid #cbd5e1",
                    padding: "6px 10px",
                    fontSize: "12px",
                    fontWeight: 500,
                    lineHeight: 1.2,
                    color: "#0f172a",
                    cursor: "pointer",
                  }}
                >
                  {tk}
                </button>
              ))}
            </div>

            {/* botón apostar */}
            <button
              onClick={handlePlaceBet}
              style={{
                width: "100%",
                backgroundColor: "#16a34a",
                border: "1px solid #15803d",
                color: "#fff",
                fontWeight: 600,
                fontSize: "13px",
                lineHeight: 1.2,
                borderRadius: "8px",
                padding: "10px 12px",
                cursor: "pointer",
              }}
            >
              Place Bet
            </button>

            {/* payout estimado */}
            <div
              style={{
                fontSize: "11px",
                lineHeight: "1.3",
                color: "#475569",
                textAlign: "right",
                marginTop: "8px",
              }}
            >
              Payout est.:{" "}
              <strong style={{ color: "#0f172a" }}>$300</strong>
            </div>
          </div>
        )}
      </section>
    </main>
  );
}
