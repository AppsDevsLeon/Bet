"use client";

import React, { useCallback } from "react";
import { ethers } from "ethers"; // v5 style import
import type { OutcomeOption, MarketCard } from "@/public/data/marketsData";

// ==================================================
// Tipos extendidos
// ==================================================
type ExtendedOutcome = OutcomeOption & {
  tokenSymbol?: string;
  tokenLogo?: string;
  tokenAddress?: string;
  chainIdHex?: string;
  id?: number | string;
};

// ==================================================
// Props
// ==================================================
type BetSlipOverlayProps = {
  market: MarketCard | null;
  outcome: OutcomeOption | null;
  stake: string;
  onChangeStake: (v: string) => void;
  onClose: () => void;
  onConfirm: () => void;
};

// ==================================================
// Componente principal
// ==================================================
export default function BetSlipOverlay({
  market,
  outcome,
  stake,
  onChangeStake,
  onClose,
  onConfirm,
}: BetSlipOverlayProps) {
  const visible = !!market && !!outcome;
  if (!visible || !market || !outcome) return null;

  // USDT Polygon mainnet (real)
  const safeOutcome: ExtendedOutcome = {
    tokenSymbol: "USDT",
    tokenLogo: "/icons/usdt.svg",
    tokenAddress: "0x3813e82e6f7098b9583FC0F33a962D02018B6803", // contrato USDT Polygon
    chainIdHex: "0x89", // Polygon Mainnet chainId
    id: (outcome as any).id ?? 0,
    ...outcome,
  };

  // tu contrato de apuestas desplegado en Polygon
  // 👇 REEMPLAZA ESTO CON EL ADDRESS REAL
  const MARKET_CONTRACT = "0xYourBettingContractAddressHere";

  // ABI mínimo de USDT que necesitamos (approve + allowance opcional)
  const USDT_ABI = [
    "function approve(address spender, uint256 amount) public returns (bool)",
    "function allowance(address owner, address spender) public view returns (uint256)",
    "function decimals() public view returns (uint8)",
  ];

  // ABI mínimo de tu contrato de apuestas
  const MARKET_ABI = [
    // tú tienes que tener una función con esta firma:
    // function bet(uint256 marketId, uint256 outcomeId, uint256 amount) public
    "function bet(uint256 marketId, uint256 outcomeId, uint256 amount) public",
  ];

  // ==================================================
  // handlePlaceBet - versión ethers v5 REAL
  // ==================================================
  const handlePlaceBet = useCallback(async () => {
    try {
      // 0) asegúrate que existe window.ethereum
      const { ethereum } = window as any;
      if (!ethereum) {
        alert("No se detectó MetaMask / wallet EVM en el navegador.");
        return;
      }

      // 1) Cambiar/sugerir Polygon
      //    En v5 igual usamos request directo al provider de la wallet
      await ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: safeOutcome.chainIdHex || "0x89" }],
      });

      // 2) Conectar MetaMask: pedir cuentas
      const accounts: string[] = await ethereum.request({
        method: "eth_requestAccounts",
      });
      const userAddress = accounts[0];
      console.log("Wallet conectada:", userAddress);

      // 3) Crear Web3Provider de ethers v5 y agarrar el signer
      const provider = new ethers.providers.Web3Provider(ethereum);
      const signer = provider.getSigner();

      // 4) Instancias de contrato (USDT y tu betting contract)
      const usdtContract = new ethers.Contract(
        safeOutcome.tokenAddress!,
        USDT_ABI,
        signer
      );

      const marketContract = new ethers.Contract(
        MARKET_CONTRACT,
        MARKET_ABI,
        signer
      );

      // 5) Parsear el stake humano ("10.5") a unidades del token.
      //    USDT Polygon normalmente usa 6 decimales, pero vamos a leerlos
      //    del contrato por si acaso.
      const tokenDecimals: number = await usdtContract.decimals();
      const floatStake = parseFloat(stake || "0");

      if (isNaN(floatStake) || floatStake <= 0) {
        alert("Monto inválido.");
        return;
      }

      // convierte "10.5" a "10500000" si decimals=6
      const rawAmount = ethers.utils.parseUnits(
        floatStake.toString(),
        tokenDecimals
      );

      console.log("Apostando:", {
        stakeHuman: stake,
        stakeRaw: rawAmount.toString(),
        tokenDecimals,
      });

      // 6) Llamar approve(contratoDeApuestas, monto)
      //    Esto abre MetaMask para que el usuario firme la aprobación.
      //    Sin esto, tu contrato no puede mover el USDT del usuario.
      console.log("Enviando approve()...");
      const approveTx = await usdtContract.approve(
        MARKET_CONTRACT,
        rawAmount
      );
      alert("Firma la aprobación de USDT en MetaMask...");
      const approveReceipt = await approveTx.wait();
      console.log("✅ approve confirmado:", approveReceipt.transactionHash);

      // 7) Llamar tu contrato bet(marketId, outcomeId, amount)
      //    Esto es tu lógica de apuesta real.
      console.log("Enviando bet()...");
      const betTx = await marketContract.bet(
        // market.id puede ser string tipo "btc-october-price"
        // tu contrato probablemente espera uint256. Ajusta según tu contrato.
        // Si tu contrato espera un número incremental (0,1,2...), entonces
        // necesitas mapear market.id a ese número.
        //
        // Por ahora te lo mando directo. Ajusta si da error de tipo.
        market.id,
        safeOutcome.id,
        rawAmount
      );

      alert("Firma la apuesta en MetaMask...");
      const betReceipt = await betTx.wait();
      console.log("✅ bet confirmada:", betReceipt.transactionHash);

      alert(
        [
          "✅ Apuesta confirmada en Polygon",
          `TX Hash: ${betReceipt.transactionHash}`,
        ].join("\n")
      );

      // 8) callback externo (puedes cerrar modal, refrescar saldo, etc.)
      onConfirm();
    } catch (err: any) {
      console.error("❌ Error en handlePlaceBet:", err);
      alert("Error o rechazo de MetaMask: " + (err?.message || err));
    }
  }, [market, outcome, stake, onConfirm, safeOutcome]);

  // ==================================================
  // UI helper para el logo del token
  // ==================================================
  const TokenAvatar = () => {
    if (safeOutcome.tokenLogo) {
      // eslint-disable-next-line @next/next/no-img-element
      return (
        <img
          src={safeOutcome.tokenLogo}
          alt={safeOutcome.tokenSymbol || "token"}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
          }}
        />
      );
    }

    return (
      <span
        style={{
          fontSize: "10px",
          fontWeight: 600,
          color: "#0f172a",
        }}
      >
        {safeOutcome.tokenSymbol || "??"}
      </span>
    );
  };

  // ==================================================
  // UI principal (caja flotante abajo derecha)
  // ==================================================
  return (
    <div
      style={{
        position: "fixed",
        right: "16px",
        bottom: "16px",
        width: "300px",
        maxWidth: "90vw",
        backgroundColor: "#ffffff",
        border: "1px solid #1a1a1a",
        borderRadius: "8px",
        boxShadow: "0 18px 40px rgba(0,0,0,0.4)",
        zIndex: 9999,
        fontFamily:
          "system-ui, -apple-system, BlinkMacSystemFont, 'Inter', sans-serif",
      }}
    >
      {/* Header */}
      <div
        style={{
          backgroundColor: "#0a1f6b",
          backgroundImage: "linear-gradient(to right, #0a1f6b, #002d8a)",
          color: "#ffffff",
          padding: "10px 12px",
          fontSize: "13px",
          fontWeight: 600,
          lineHeight: 1.2,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderTopLeftRadius: "8px",
          borderTopRightRadius: "8px",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
          <div style={{ fontWeight: 600, fontSize: "13px", lineHeight: 1.2 }}>
            Bet Slip
          </div>
          <div
            style={{
              fontSize: "11px",
              lineHeight: 1.2,
              fontWeight: 400,
              opacity: 0.9,
            }}
          >
            {market.title}
          </div>
        </div>

        <button
          onClick={onClose}
          style={{
            background: "transparent",
            border: "0",
            color: "#fff",
            fontSize: "14px",
            cursor: "pointer",
            lineHeight: 1,
          }}
        >
          ✕
        </button>
      </div>

      {/* Body */}
      <div style={{ padding: "12px", fontSize: "13px", color: "#0f172a" }}>
        {/* Token info */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            marginBottom: "12px",
            gap: "8px",
          }}
        >
          <div
            style={{
              width: "28px",
              height: "28px",
              borderRadius: "999px",
              border: "1px solid #e2e8f0",
              background: "#fff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              overflow: "hidden",
            }}
          >
            <TokenAvatar />
          </div>

          <div style={{ lineHeight: 1.2 }}>
            <div
              style={{
                fontSize: "12px",
                color: "#475569",
              }}
            >
              Paying with
            </div>
            <div
              style={{
                fontSize: "13px",
                fontWeight: 600,
                color: "#0f172a",
              }}
            >
              {safeOutcome.tokenSymbol || "TOKEN"} · Polygon
            </div>
          </div>
        </div>

        {/* Outcome seleccionado */}
        <div
          style={{
            border: "1px solid #e2e8f0",
            borderRadius: "6px",
            padding: "8px 10px",
            marginBottom: "12px",
            lineHeight: 1.4,
            backgroundColor: "#f8fafc",
          }}
        >
          <div
            style={{
              fontSize: "12px",
              lineHeight: 1.2,
              color: "#475569",
              marginBottom: "2px",
            }}
          >
            Selected Outcome
          </div>
          <div style={{ fontWeight: 600, color: "#0f172a", fontSize: "13px" }}>
            {safeOutcome.label ?? ""}{" "}
            {safeOutcome.price ? `(${safeOutcome.price})` : ""}
          </div>
        </div>

        {/* Stake input */}
        <label
          style={{
            display: "block",
            fontSize: "12px",
            color: "#475569",
            marginBottom: "4px",
          }}
        >
          Stake ({safeOutcome.tokenSymbol || "TOKEN"})
        </label>
        <input
          value={stake}
          onChange={(e) => onChangeStake(e.target.value)}
          placeholder="0.00"
          style={{
            width: "100%",
            borderRadius: "6px",
            border: "1px solid #94a3b8",
            padding: "8px 10px",
            fontSize: "13px",
            lineHeight: 1.4,
            color: "#0f172a",
            outline: "none",
            marginBottom: "12px",
          }}
        />

        {/* Botón apostar */}
        <button
          onClick={handlePlaceBet}
          style={{
            width: "100%",
            backgroundColor: "#16a34a",
            border: "1px solid #15803d",
            borderRadius: "6px",
            color: "#ffffff",
            fontSize: "13px",
            fontWeight: 600,
            lineHeight: 1.2,
            padding: "10px",
            cursor: "pointer",
          }}
        >
          Place Bet (Polygon)
        </button>

        {/* Nota */}
        <div
          style={{
            color: "#475569",
            fontSize: "11px",
            lineHeight: 1.4,
            textAlign: "center",
            marginTop: "8px",
          }}
        >
          Esto va a pedirte 2 firmas en MetaMask:
          1) approve USDT, 2) bet() en tu contrato.
        </div>
      </div>
    </div>
  );
}
