"use client";

import React, { useState } from "react";
import Link from "next/link";
import type {
  MarketCard as MarketCardType,
  OutcomeOption,
} from "@/public/data/marketsData";

/* =========================
   Helpers visuales
========================= */

function getPriceColor(tone?: "green" | "red" | "neutral") {
  if (tone === "green") return "#047857";
  if (tone === "red") return "#e11d48";
  return "#0f172a";
}

function StaticPill({ kind }: { kind: "yes" | "no" }) {
  const base: React.CSSProperties = {
    fontSize: "12px",
    fontWeight: 500,
    lineHeight: 1,
    borderWidth: "1px",
    borderStyle: "solid",
    padding: "2px 6px",
    display: "inline-block",
    borderRadius: "4px",
    fontFamily:
      "system-ui, -apple-system, BlinkMacSystemFont, 'Inter', sans-serif",
  };

  if (kind === "yes") {
    return (
      <span
        style={{
          ...base,
          color: "#065f46",
          backgroundColor: "#ecfdf5",
          borderColor: "#a7f3d0",
        }}
      >
        Yes
      </span>
    );
  }

  return (
    <span
      style={{
        ...base,
        color: "#be123c",
        backgroundColor: "#fff1f2",
        borderColor: "#fecdd3",
      }}
    >
      No
    </span>
  );
}

/* =========================
   Fila mercado binario yes/no
========================= */

function OutcomeRowYesNo({
  opt,
  onClick,
}: {
  opt: OutcomeOption;
  onClick: () => void;
}) {
  const isYes = opt.label.trim().toLowerCase() === "yes";
  const isNo = opt.label.trim().toLowerCase() === "no";

  return (
    <button
      onClick={onClick}
      style={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "8px",
        backgroundColor: "transparent",
        border: "0",
        textAlign: "left",
        cursor: "pointer",
        padding: "10px 0",
        fontFamily:
          "system-ui, -apple-system, BlinkMacSystemFont, 'Inter', sans-serif",
      }}
    >
      {/* izquierda: sólo la pill */}
      <div
        style={{
          fontSize: "14px",
          lineHeight: "1.4",
          fontWeight: 400,
          display: "flex",
          alignItems: "center",
          gap: "8px",
        }}
      >
        {isYes && <StaticPill kind="yes" />}
        {isNo && <StaticPill kind="no" />}
      </div>

      {/* derecha: porcentaje */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          flexShrink: 0,
        }}
      >
        {opt.price && (
          <div
            style={{
              fontSize: "14px",
              lineHeight: 1,
              fontWeight: 600,
              fontVariantNumeric: "tabular-nums",
              color: getPriceColor(opt.tone),
            }}
          >
            {opt.price}
          </div>
        )}
      </div>
    </button>
  );
}

/* =========================
   Pills hover Yes/No multi-opción
========================= */

function HoverPill({
  kind,
  correct,
  incorrect,
}: {
  kind: "yes" | "no";
  correct?: string;
  incorrect?: string;
}) {
  const [hover, setHover] = useState(false);

  const base: React.CSSProperties = {
    fontSize: "12px",
    fontWeight: 500,
    lineHeight: 1,
    borderWidth: "1px",
    borderStyle: "solid",
    padding: "6px 8px",
    minWidth: "44px",
    textAlign: "center",
    borderRadius: "4px",
    cursor: "pointer",
    fontFamily:
      "system-ui, -apple-system, BlinkMacSystemFont, 'Inter', sans-serif",
  };

  if (kind === "yes") {
    return (
      <span
        style={{
          ...base,
          color: "#065f46",
          backgroundColor: "#ecfdf5",
          borderColor: "#a7f3d0",
        }}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      >
        {hover && correct ? correct : "Yes"}
      </span>
    );
  }

  return (
    <span
      style={{
        ...base,
        color: "#be123c",
        backgroundColor: "#fff1f2",
        borderColor: "#fecdd3",
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {hover && incorrect ? incorrect : "No"}
    </span>
  );
}

/* =========================
   Fila mercado multi-opción
   [ Label ] [ % ] [ Yes ] [ No ]
========================= */

function OutcomeRowMulti({
  opt,
  onClick,
}: {
  opt: OutcomeOption;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        width: "100%",
        backgroundColor: "transparent",
        border: "0",
        textAlign: "left",
        cursor: "pointer",
        padding: "10px 0",
        fontFamily:
          "system-ui, -apple-system, BlinkMacSystemFont, 'Inter', sans-serif",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "12px",
          flexWrap: "nowrap",
        }}
      >
        {/* label izquierda */}
        <div
          style={{
            flex: "1 1 auto",
            minWidth: 0,
            fontSize: "14px",
            lineHeight: "1.4",
            color: "#1e293b",
            fontWeight: 500,
            wordBreak: "break-word",
          }}
        >
          {opt.label}
        </div>

        {/* porcentaje centro */}
        <div
          style={{
            flexShrink: 0,
            minWidth: "36px",
            textAlign: "right",
            fontSize: "14px",
            lineHeight: 1,
            fontWeight: 600,
            fontVariantNumeric: "tabular-nums",
            color: getPriceColor(opt.tone),
          }}
        >
          {opt.price || "--"}
        </div>

        {/* pills derecha */}
        <div
          style={{
            flexShrink: 0,
            display: "flex",
            alignItems: "center",
            gap: "8px",
          }}
        >
          <HoverPill
            kind="yes"
            correct={opt.probCorrect}
            incorrect={opt.probIncorrect}
          />
          <HoverPill
            kind="no"
            correct={opt.probCorrect}
            incorrect={opt.probIncorrect}
          />
        </div>
      </div>
    </button>
  );
}

/* =========================
   Barra probabilidad bajo el título
========================= */

function getProbabilityNumber(probLabel?: string): number | null {
  if (!probLabel) return null;
  const firstPart = probLabel.split(" ")[0];
  if (!firstPart) return null;
  if (firstPart.startsWith("<")) return 1;

  const numStr = firstPart.replace("%", "");
  const numVal = Number(numStr);
  if (isNaN(numVal)) return null;
  if (numVal < 0) return 0;
  if (numVal > 100) return 100;
  return numVal;
}

function ProbabilityBlock({ probLabel }: { probLabel?: string }) {
  const pct = getProbabilityNumber(probLabel);
  if (!probLabel || pct === null) return null;

  const percentText = probLabel.split(" ")[0];
  const restText = probLabel.replace(/^\S+\s*/, "");

  return (
    <div
      style={{
        width: "100%",
        display: "flex",
        flexDirection: "column",
        marginTop: "8px",
        marginBottom: "8px",
        fontFamily:
          "system-ui, -apple-system, BlinkMacSystemFont, 'Inter', sans-serif",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          lineHeight: 1.2,
        }}
      >
        <div
          style={{
            fontSize: "13px",
            fontWeight: 600,
            color: "#0f172a",
          }}
        >
          {percentText}
        </div>

        <div
          style={{
            fontSize: "11px",
            color: "#64748b",
            fontWeight: 400,
          }}
        >
          {restText || "chance"}
        </div>
      </div>

      <div
        style={{
          marginTop: "6px",
          width: "100%",
          height: "4px",
          backgroundColor: "#e2e8f0",
          overflow: "hidden",
          borderRadius: "2px",
        }}
      >
        <div
          style={{
            width: `${pct}%`,
            maxWidth: "100%",
            height: "100%",
            backgroundColor: "#1E3C8E",
            transition: "width 0.15s linear",
          }}
        />
      </div>
    </div>
  );
}

/* =========================
   Contenedor de outcomes con scrollbar custom
========================= */

function OutcomesSection({
  market,
  onSelectOutcome,
}: {
  market: MarketCardType;
  onSelectOutcome: (m: MarketCardType, o: OutcomeOption) => void;
}) {
  const isYesNo = market.marketType === "yesno";

  // estilo base
  const containerStyle: React.CSSProperties = {
    borderTop: "1px solid #e2e8f0",
    maxHeight: isYesNo ? "unset" : "200px",
    overflowY: isYesNo ? "visible" : "auto",
    paddingRight: isYesNo ? undefined : "12px", // espacio del lado derecho
  };

  // si es multi con scroll => agregamos class para el scrollbar custom
  const containerClass = isYesNo ? undefined : "outcomes-scrollarea";

  return (
    <div style={containerStyle} className={containerClass}>
      {market.outcomes.map((opt, idx) => (
        <div
          key={idx}
          style={{
            borderBottom:
              idx === market.outcomes.length - 1
                ? "0"
                : "1px solid #e2e8f0",
          }}
        >
          {isYesNo ? (
            <OutcomeRowYesNo
              opt={opt}
              onClick={() => onSelectOutcome(market, opt)}
            />
          ) : (
            <OutcomeRowMulti
              opt={opt}
              onClick={() => onSelectOutcome(market, opt)}
            />
          )}
        </div>
      ))}
    </div>
  );
}

/* =========================
   CARD PRINCIPAL
========================= */

export default function MarketCardSimple({
  market,
  onSelectOutcome,
}: {
  market?: MarketCardType;
  onSelectOutcome: (m: MarketCardType, o: OutcomeOption) => void;
}) {
  if (!market) {
    return (
      <div
        style={{
          border: "1px solid #e2e8f0",
          backgroundColor: "#ffffff",
          padding: "12px",
          fontSize: "13px",
          color: "#64748b",
          fontFamily:
            "system-ui, -apple-system, BlinkMacSystemFont, 'Inter', sans-serif",
        }}
      >
        (no market data)
      </div>
    );
  }

  return (
    <div
      style={{
        border: "1px solid #e2e8f0",
        backgroundColor: "#ffffff",
        padding: "12px 16px",
        display: "flex",
        flexDirection: "column",
        minWidth: 0,
        fontFamily:
          "system-ui, -apple-system, BlinkMacSystemFont, 'Inter', sans-serif",
        lineHeight: 1.4,
      }}
    >
      {/* HEADER */}
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
          width: "100%",
          gap: "12px",
          marginBottom: "8px",
        }}
      >
        {/* ICONO */}
        <div
          style={{
            flexShrink: 0,
            width: "32px",
            height: "32px",
            border: "1px solid #e2e8f0",
            backgroundColor: "#fff",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            overflow: "hidden",
          }}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={market.icon}
            alt={market.title}
            style={{
              width: "28px",
              height: "28px",
              objectFit: "contain",
              display: "block",
            }}
          />
        </div>

        {/* TÍTULO + SUBTÍTULO */}
        <div
          style={{
            flex: "1 1 auto",
            minWidth: 0,
          }}
        >
          <div
            style={{
              fontSize: "14px",
              fontWeight: 600,
              lineHeight: "1.3",
              color: "#0f172a",
              wordBreak: "break-word",
            }}
          >
            {market.title}
          </div>

          {market.subtitle ? (
            <div
              style={{
                fontSize: "12px",
                lineHeight: "1.3",
                color: "#64748b",
                marginTop: "2px",
                fontWeight: 400,
              }}
            >
              {market.subtitle}
            </div>
          ) : null}
        </div>
      </div>

      {/* Barra de probabilidad justo debajo de la pregunta */}
      <ProbabilityBlock probLabel={market.probabilityLabel} />

      {/* Outcomes con scrollbar bonito */}
      <OutcomesSection market={market} onSelectOutcome={onSelectOutcome} />

      {/* FOOTER */}
      {(market.isLive || market.volume) && (
        <div
          style={{
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "space-between",
            flexWrap: "wrap",
            fontSize: "11px",
            lineHeight: "1.2",
            color: "#64748b",
            paddingTop: "8px",
          }}
        >
          {/* izquierda: LIVE + volumen */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              flexWrap: "wrap",
              gap: "8px",
              rowGap: "4px",
              fontWeight: 400,
            }}
          >
            {market.isLive && (
              <span
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "4px",
                  fontWeight: 600,
                  color: "#e11d48",
                }}
              >
                <span
                  style={{
                    width: "6px",
                    height: "6px",
                    borderRadius: "9999px",
                    backgroundColor: "#e11d48",
                  }}
                />
                LIVE
              </span>
            )}

            {market.volume && (
              <span
                style={{
                  color: "#64748b",
                  fontWeight: 400,
                }}
              >
                {market.volume}
              </span>
            )}
          </div>

          {/* derecha: promociones */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              color: "#94a3b8",
              fontWeight: 400,
            }}
          >
            <Link
              href="/promotions"
              style={{
                background: "transparent",
                border: 0,
                padding: 0,
                cursor: "pointer",
                fontSize: "14px",
                lineHeight: 1,
                color: "#94a3b8",
                textDecoration: "none",
              }}
              title="Promotions / Bonuses"
            >
              🎁
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
