// /public/data/marketsData.ts

export type OutcomeOption = {
  label: string;   // ">$1.2B", "↑ 200k", "October 31", "Yes", "No"
  price: string;   // "100%", "<1%", "9%"
  tone?: "green" | "red" | "neutral";

  // Solo para mercados con muchas opciones (marketType = "multi")
  // Es la probabilidad de que este outcome sea el que pase,
  // y la probabilidad de que NO pase.
  probCorrect?: string;   // ej "27%"
  probIncorrect?: string; // ej "73%"
};

export type MarketCard = {
  id: string;
  assetTag: string; // "btc" | "eth" | "xrp" | "macro" | "airdrop" | ...
  rangeTag: string; // "1m" | "1w" | "weekly" | "premarket" | ...
  icon: string;     // ruta al icono (public/)
  title: string;
  subtitle?: string;

  // NUEVO: tipo de carta para la UI
  marketType: "yesno" | "multi";

  isLive: boolean;
  volume: string;  // "$54m Vol."
  probabilityLabel?: string; // "<1% chance" arriba a la derecha en algunas cartas tipo yes/no
  outcomes: OutcomeOption[];
};

/* =========================
   DATA DE MERCADOS
   ========================= */

export const MARKETS: MarketCard[] = [
  {
    id: "megaeth-sale",
    assetTag: "eth",
    rangeTag: "1m",
    icon: "/coins/ethereum.png",
    title: "MegaETH public sale total commitments?",
    subtitle: "Total capital committed during public round",
    marketType: "multi",
    isLive: false,
    volume: "$54m Vol.",
    probabilityLabel: undefined,
    outcomes: [
      {
        label: ">$1.0B",
        price: "82%",
        tone: "green",
        probCorrect: "82%",
        probIncorrect: "18%",
      },
      {
        label: ">$1.2B",
        price: "68%",
        tone: "green",
        probCorrect: "68%",
        probIncorrect: "32%",
      },
      {
        label: ">$1.3B",
        price: "41%",
        tone: "neutral",
        probCorrect: "41%",
        probIncorrect: "59%",
      },
      {
        label: ">$1.5B",
        price: "12%",
        tone: "red",
        probCorrect: "12%",
        probIncorrect: "88%",
      },
    ],
  },

  {
    id: "btc-october-price",
    assetTag: "btc",
    rangeTag: "1m",
    icon: "/coins/bitcoin.png",
    title: "What price will Bitcoin hit in October?",
    subtitle: "Highest print before Oct 31 23:59 UTC",
    marketType: "multi",
    isLive: false,
    volume: "$97m Vol.",
    probabilityLabel: undefined,
    outcomes: [
      {
        label: "↑ 200k",
        price: "<1%",
        tone: "neutral",
        probCorrect: "1%",
        probIncorrect: "99%",
      },
      {
        label: "↑ 180k",
        price: "3%",
        tone: "red",
        probCorrect: "3%",
        probIncorrect: "97%",
      },
      {
        label: "↑ 150k",
        price: "9%",
        tone: "neutral",
        probCorrect: "9%",
        probIncorrect: "91%",
      },
      {
        label: "↑ 120k",
        price: "27%",
        tone: "green",
        probCorrect: "27%",
        probIncorrect: "73%",
      },
      {
        label: "↑ 100k",
        price: "44%",
        tone: "green",
        probCorrect: "44%",
        probIncorrect: "56%",
      },
      {
        label: "< 100k",
        price: "16%",
        tone: "red",
        probCorrect: "16%",
        probIncorrect: "84%",
      },
    ],
  },

  {
    id: "eth-october-price",
    assetTag: "eth",
    rangeTag: "1m",
    icon: "/coins/ethereum.png",
    title: "What price will Ethereum hit in October?",
    subtitle: "Local top for ETH in October",
    marketType: "multi",
    isLive: false,
    volume: "$63m Vol.",
    probabilityLabel: undefined,
    outcomes: [
      {
        label: "↑ 8000",
        price: "<1%",
        tone: "neutral",
        probCorrect: "1%",
        probIncorrect: "99%",
      },
      {
        label: "↑ 7000",
        price: "2%",
        tone: "red",
        probCorrect: "2%",
        probIncorrect: "98%",
      },
      {
        label: "↑ 6000",
        price: "6%",
        tone: "neutral",
        probCorrect: "6%",
        probIncorrect: "94%",
      },
      {
        label: "↑ 5000",
        price: "22%",
        tone: "green",
        probCorrect: "22%",
        probIncorrect: "78%",
      },
      {
        label: "↑ 4000",
        price: "38%",
        tone: "green",
        probCorrect: "38%",
        probIncorrect: "62%",
      },
      {
        label: "< 4000",
        price: "31%",
        tone: "red",
        probCorrect: "31%",
        probIncorrect: "69%",
      },
    ],
  },

  {
    id: "btc-above-oct30",
    assetTag: "btc",
    rangeTag: "1m",
    icon: "/coins/bitcoin.png",
    title: "Bitcoin above __ on October 30?",
    subtitle: "Closing price snapshot Oct 30 23:59 UTC",
    marketType: "multi",
    isLive: false,
    volume: "$21m Vol.",
    probabilityLabel: undefined,
    outcomes: [
      {
        label: "100,000",
        price: "61%",
        tone: "green",
        probCorrect: "61%",
        probIncorrect: "39%",
      },
      {
        label: "102,000",
        price: "47%",
        tone: "green",
        probCorrect: "47%",
        probIncorrect: "53%",
      },
      {
        label: "105,000",
        price: "23%",
        tone: "neutral",
        probCorrect: "23%",
        probIncorrect: "77%",
      },
      {
        label: "110,000",
        price: "9%",
        tone: "red",
        probCorrect: "9%",
        probIncorrect: "91%",
      },
    ],
  },

  {
    id: "eth-ath-oct31",
    assetTag: "eth",
    rangeTag: "1m",
    icon: "/coins/ethereum.png",
    title: "Ethereum all time high by October 31?",
    subtitle: "Does ETH print new ATH before Oct 31?",
    marketType: "yesno",
    isLive: false,
    volume: "$14m Vol.",
    probabilityLabel: "<1% chance",
    outcomes: [
      {
        label: "Yes",
        price: "1%",
        tone: "green",
        // en yes/no no metemos probCorrect / probIncorrect
      },
      {
        label: "No",
        price: "99%",
        tone: "red",
      },
    ],
  },

  {
    id: "monad-airdrop",
    assetTag: "airdrop",
    rangeTag: "premarket",
    icon: "/icons/airdrop-token.png",
    title: "Monad airdrop date?",
    subtitle: "When will MONAD token drop to wallets?",
    marketType: "multi",
    isLive: false,
    volume: "$14m Vol.",
    probabilityLabel: undefined,
    outcomes: [
      {
        label: "October 31",
        price: "<1%",
        tone: "neutral",
        probCorrect: "1%",
        probIncorrect: "99%",
      },
      {
        label: "November 15",
        price: "9%",
        tone: "green",
        probCorrect: "9%",
        probIncorrect: "91%",
      },
      {
        label: "November 30",
        price: "27%",
        tone: "green",
        probCorrect: "27%",
        probIncorrect: "73%",
      },
      {
        label: "December or later",
        price: "63%",
        tone: "red",
        probCorrect: "63%",
        probIncorrect: "37%",
      },
    ],
  },

  {
    id: "xrp-october-price",
    assetTag: "xrp",
    rangeTag: "1m",
    icon: "/coins/xrp.png",
    title: "What price will XRP hit in October?",
    subtitle: "Local high for XRP in October",
    marketType: "multi",
    isLive: false,
    volume: "$8m Vol.",
    probabilityLabel: undefined,
    outcomes: [
      {
        label: "↑ 6.00",
        price: "<1%",
        tone: "neutral",
        probCorrect: "1%",
        probIncorrect: "99%",
      },
      {
        label: "↑ 4.50",
        price: "4%",
        tone: "neutral",
        probCorrect: "4%",
        probIncorrect: "96%",
      },
      {
        label: "↑ 3.00",
        price: "18%",
        tone: "green",
        probCorrect: "18%",
        probIncorrect: "82%",
      },
      {
        label: "↑ 2.00",
        price: "42%",
        tone: "green",
        probCorrect: "42%",
        probIncorrect: "58%",
      },
      {
        label: "< 2.00",
        price: "35%",
        tone: "red",
        probCorrect: "35%",
        probIncorrect: "65%",
      },
    ],
  },

  {
    id: "btc-oct27-nov2",
    assetTag: "btc",
    rangeTag: "weekly",
    icon: "/coins/bitcoin.png",
    title: "What price will Bitcoin hit October 27–November 2?",
    subtitle: "Weekly range high 27 Oct – 2 Nov",
    marketType: "multi",
    isLive: false,
    volume: "$32m Vol.",
    probabilityLabel: undefined,
    outcomes: [
      {
        label: "↑ 128,000",
        price: "<1%",
        tone: "neutral",
        probCorrect: "1%",
        probIncorrect: "99%",
      },
      {
        label: "↑ 126,000",
        price: "1%",
        tone: "green",
        probCorrect: "1%",
        probIncorrect: "99%",
      },
      {
        label: "↑ 122,000",
        price: "7%",
        tone: "neutral",
        probCorrect: "7%",
        probIncorrect: "93%",
      },
      {
        label: "↑ 118,000",
        price: "19%",
        tone: "green",
        probCorrect: "19%",
        probIncorrect: "81%",
      },
      {
        label: "↑ 110,000",
        price: "44%",
        tone: "green",
        probCorrect: "44%",
        probIncorrect: "56%",
      },
      {
        label: "< 110,000",
        price: "28%",
        tone: "red",
        probCorrect: "28%",
        probIncorrect: "72%",
      },
    ],
  },

  {
    id: "eth-above-oct30",
    assetTag: "eth",
    rangeTag: "1m",
    icon: "/coins/ethereum.png",
    title: "Ethereum above __ on October 30?",
    subtitle: "ETH close above target on Oct 30",
    marketType: "multi",
    isLive: false,
    volume: "$19m Vol.",
    probabilityLabel: undefined,
    outcomes: [
      {
        label: "3,400",
        price: "99%",
        tone: "green",
        probCorrect: "99%",
        probIncorrect: "1%",
      },
      {
        label: "3,500",
        price: "100%",
        tone: "green",
        probCorrect: "100%",
        probIncorrect: "0%",
      },
      {
        label: "3,700",
        price: "72%",
        tone: "green",
        probCorrect: "72%",
        probIncorrect: "28%",
      },
      {
        label: "4,000",
        price: "31%",
        tone: "neutral",
        probCorrect: "31%",
        probIncorrect: "69%",
      },
      {
        label: "4,500",
        price: "9%",
        tone: "red",
        probCorrect: "9%",
        probIncorrect: "91%",
      },
    ],
  },
];
