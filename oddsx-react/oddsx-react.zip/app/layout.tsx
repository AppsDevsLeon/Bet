import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "@/public/scss/style.scss";
import MainFooter from "@/components/Shared/MainFooter";
import FooterCard from "@/components/Shared/FooterCard";
import { I18nProvider } from "@/lib/i18n/I18nProvider";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Oddsx - Sports Betting React Next",
  description: "Made with nextjs bootstrap 5 & Sass",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es">
      <body className={inter.className}>
        {/* 👇 Proveedor de idiomas, sin mover tus rutas */}
        <I18nProvider defaultLocale="es">
          <main>
            {children}
            <FooterCard />
            <MainFooter />
          </main>
        </I18nProvider>
      </body>
    </html>
  );
}
