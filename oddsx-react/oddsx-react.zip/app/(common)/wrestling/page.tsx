import NFLSection from '@/components/Pages/AmericanFootball/UpCmingAmericanFootball';

export default function page() {
    return (
        <>

                 <NFLSection sportSlug="nfl" />
        </>
    )
}