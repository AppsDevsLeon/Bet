
import TopTableTennis from '@/components/Pages/TableTennis/TopTableTennis';
import UpCmingTableTennis from '@/components/Pages/TableTennis/UpCmingTableTennis';

export default function page() {
    return (
        <>

            <TopTableTennis />
            <UpCmingTableTennis />
        </>
    )
}