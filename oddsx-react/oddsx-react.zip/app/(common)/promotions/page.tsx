import Promotions from '@/components/Pages/Promotions/Promotions'

import React from 'react'

export default function page() {
  return (
      <>
     
          <Promotions />
      </>
  )
}
