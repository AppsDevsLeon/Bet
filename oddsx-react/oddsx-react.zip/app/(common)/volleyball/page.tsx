
import UpCmingVolleyball from '@/components/Pages/Volleyball/UpCmingVolleyball';

export default function page() {
    return (
        <>
   
            <UpCmingVolleyball />
        </>
    )
}
