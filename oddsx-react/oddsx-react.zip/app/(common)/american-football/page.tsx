
import NFLSection from '@/components/Pages/AmericanFootball/UpCmingAmericanFootball';

export default function Page() {
  return (
    <>
      <div className="page-under-header">
        <div className="page-under-header-inner">
          <NFLSection sportSlug="nfl" />
        </div>
      </div>

    </>
  );
}

