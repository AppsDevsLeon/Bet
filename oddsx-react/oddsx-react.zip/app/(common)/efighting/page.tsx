import HeaderMain from '@/components/Shared/HeaderMain';
import TopEfighting from '@/components/Pages/Efighting/TopEfighting';

export default function page() {
    return (
        <>
            <HeaderMain />
            <TopEfighting />
        </>
    )
}