import CryptoMarket from '@/components/Pages/crypto/MarketsCryptoPage';

export default function page() {
    return (
        <div className="page-under-header">
            <div className="page-under-header-inner">
                <CryptoMarket />
            </div>
        </div>



    )
}