import HeroWorldCupBanner from "@/components/banner/FifaPromoBanner";
import WorldCupBracket  from "@/components/worldcup/WorldCupBracket";
export default function Page() {
  return (
    <>
      <HeroWorldCupBanner />
      <WorldCupBracket />
    </>
  );
}
