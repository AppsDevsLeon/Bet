import TopSquash from '@/components/Pages/squash/TopSquash';


export default function page() {
    return (
        <>
       
            <TopSquash />
        </>
    )
}