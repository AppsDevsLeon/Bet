
import UpCmingHandball from '@/components/Pages/Handball/UpCmingHandball';

export default function page() {
    return (
        <>
     
            <UpCmingHandball />
        </>
    )
}
